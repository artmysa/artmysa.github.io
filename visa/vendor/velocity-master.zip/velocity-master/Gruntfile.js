module.exports = function(grunt) {
	"use strict";

	require("load-grunt-tasks")(grunt);
};
