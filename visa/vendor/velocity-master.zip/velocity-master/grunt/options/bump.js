module.exports = {
	main: {
		options: {
			updateConfigs: ["pkg"],
			commitFiles: ["package.json"],
			pushTo: "origin"
		}
	}
};
