///<reference path="actions.ts" />
///<reference path="finish.ts" />
///<reference path="option.ts" />
///<reference path="pauseResume.ts" />
///<reference path="reverse.ts" />
///<reference path="stop.ts" />
///<reference path="style.ts" />
///<reference path="tween.ts" />
