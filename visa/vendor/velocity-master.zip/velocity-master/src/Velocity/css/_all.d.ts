///<reference path="camelCase.ts" />
///<reference path="colors.ts" />
///<reference path="fixColors.ts" />
///<reference path="getPropertyValue.ts" />
///<reference path="getUnit.ts" />
///<reference path="setPropertyValue.ts" />
