///<reference path="easings.ts" />
///<reference path="back.ts" />
///<reference path="bezier.ts" />
///<reference path="bounce.ts" />
///<reference path="elastic.ts" />
///<reference path="spring_rk4.ts" />
///<reference path="step.ts" />
///<reference path="string.ts" />
