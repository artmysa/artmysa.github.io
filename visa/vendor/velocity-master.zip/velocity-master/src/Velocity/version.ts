/*
 * VelocityJS.org (C) 2014-2017 Julian Shapiro.
 *
 * Licensed under the MIT license. See LICENSE file in the project root for details.
 * 
 * Velocity version (should grab from package.json during build).
 */

namespace VelocityStatic {
	export let version = "2.0.2";
};
