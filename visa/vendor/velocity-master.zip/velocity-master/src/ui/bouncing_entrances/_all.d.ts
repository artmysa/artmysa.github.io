///<reference path="./bounceIn.ts" />
///<reference path="./bounceInDown.ts" />
///<reference path="./bounceInLeft.ts" />
///<reference path="./bounceInRight.ts" />
///<reference path="./bounceInUp.ts" />
