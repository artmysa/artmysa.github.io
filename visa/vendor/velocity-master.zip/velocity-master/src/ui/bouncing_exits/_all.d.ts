///<reference path="bounceOut.ts" />
///<reference path="bounceOutDown.ts" />
///<reference path="bounceOutLeft.ts" />
///<reference path="bounceOutRight.ts" />
///<reference path="bounceOutUp.ts" />
