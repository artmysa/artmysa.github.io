///<reference path="lightSpeedIn.ts" />
///<reference path="lightSpeedOut.ts" />
