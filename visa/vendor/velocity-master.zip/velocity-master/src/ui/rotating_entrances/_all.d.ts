///<reference path="rotateIn.ts" />
///<reference path="rotateInDownLeft.ts" />
///<reference path="rotateInDownRight.ts" />
///<reference path="rotateInUpLeft.ts" />
///<reference path="rotateInUpRight.ts" />
