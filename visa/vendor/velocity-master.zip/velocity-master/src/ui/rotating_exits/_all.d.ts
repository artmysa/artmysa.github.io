///<reference path="rotateOut.ts" />
///<reference path="rotateOutDownLeft.ts" />
///<reference path="rotateOutDownRight.ts" />
///<reference path="rotateOutUpLeft.ts" />
///<reference path="rotateOutUpRight.ts" />
