///<reference path="slideInDown.ts" />
///<reference path="slideInLeft.ts" />
///<reference path="slideInRight.ts" />
///<reference path="slideInUp.ts" />
