///<reference path="slideOutDown.ts" />
///<reference path="slideOutLeft.ts" />
///<reference path="slideOutRight.ts" />
///<reference path="slideOutUp.ts" />
