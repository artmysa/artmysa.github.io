///<reference path="hinge.ts" />
///<reference path="jackInTheBox.ts" />
///<reference path="rollIn.ts" />
///<reference path="rollOut.ts" />
