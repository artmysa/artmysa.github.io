///<reference path="zoomIn.ts" />
///<reference path="zoomInDown.ts" />
///<reference path="zoomInLeft.ts" />
///<reference path="zoomInRight.ts" />
///<reference path="zoomInUp.ts" />
