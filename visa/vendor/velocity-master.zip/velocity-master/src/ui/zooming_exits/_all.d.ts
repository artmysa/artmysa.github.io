///<reference path="zoomOut.ts" />
///<reference path="zoomOutDown.ts" />
///<reference path="zoomOutLeft.ts" />
///<reference path="zoomOutRight.ts" />
///<reference path="zoomOutUp.ts" />
