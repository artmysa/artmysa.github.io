///<reference path="_module.ts" />
///<reference path="Arguments.ts" />
///<reference path="End Value Caching.ts" />
///<reference path="End Value Setting.ts" />
///<reference path="Start Value Calculation.ts" />
///<reference path="Unit Calculation.ts" />
/*
 * VelocityJS.org (C) 2014-2017 Julian Shapiro.
 *
 * Licensed under the MIT license. See LICENSE file in the project root for details.
 */
