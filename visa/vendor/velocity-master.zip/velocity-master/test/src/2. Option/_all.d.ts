///<reference path="_module.ts" />
///<reference path="Option Begin.ts" />
///<reference path="Option Complete.ts" />
///<reference path="Option Delay.ts" />
///<reference path="Option Easing.ts" />
///<reference path="Option Fps Limit.ts" />
///<reference path="Option Loop.ts" />
///<reference path="Option Progress.ts" />
///<reference path="Option Queue.ts" />
///<reference path="Option Repeat.ts" />
///<reference path="Option Speed.ts" />
///<reference path="Option Sync.ts" />
/*
 * VelocityJS.org (C) 2014-2017 Julian Shapiro.
 *
 * Licensed under the MIT license. See LICENSE file in the project root for details.
 */
