///<reference path="_module.ts" />
///<reference path="Command Finish.ts" />
///<reference path="Command Pause + Resume.ts" />
///<reference path="Command Reverse.ts" />
///<reference path="Command Scroll.ts" />
///<reference path="Command Stop.ts" />
///<reference path="Command Tween.ts" />
/*
 * VelocityJS.org (C) 2014-2017 Julian Shapiro.
 *
 * Licensed under the MIT license. See LICENSE file in the project root for details.
 */
