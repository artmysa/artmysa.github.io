///<reference path="_module.ts" />
///<reference path="Feature Classname.ts" />
///<reference path="Feature Colors.ts" />
///<reference path="Feature Forcefeeding.ts" />
///<reference path="Feature Promises.ts" />
///<reference path="Feature Sequences.ts" />
///<reference path="Feature Value Functions.ts" />
/*
 * VelocityJS.org (C) 2014-2017 Julian Shapiro.
 *
 * Licensed under the MIT license. See LICENSE file in the project root for details.
 */
