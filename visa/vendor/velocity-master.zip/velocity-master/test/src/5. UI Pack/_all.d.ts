///<reference path="_module.ts" />
///<reference path="Packaged Effect slideUp+Down.ts" />
///<reference path="UI Pack Call Options.ts" />
///<reference path="UI Pack Callbacks.ts" />
///<reference path="UI Pack In+Out.ts" />
///<reference path="UI Pack RegisterEffect.ts" />
///<reference path="UI Pack RunSequence.ts" />
/*
 * VelocityJS.org (C) 2014-2017 Julian Shapiro.
 *
 * Licensed under the MIT license. See LICENSE file in the project root for details.
 */
